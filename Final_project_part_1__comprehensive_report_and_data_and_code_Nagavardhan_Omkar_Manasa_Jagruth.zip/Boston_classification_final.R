# Install necessary libraries if not already installed
install.packages(c("randomForest", "e1071", "caret", "ggplot2", "pROC"))

# Load libraries
library(randomForest)    # For Random Forest
library(e1071)           # For Support Vector Machine (SVM)
library(caret)           # For train/test split and model evaluation
library(ggplot2)         # For visualization
library(pROC)            # For ROC curve

# Step 1: Load the Boston housing price dataset from the URL
boston <- read.csv("https://raw.githubusercontent.com/selva86/datasets/master/BostonHousing.csv")

# Step 2: Transform the 'medv' variable into a categorical variable (high price vs low price)
# Set threshold for classification (for example, median of 'medv' as the threshold)
threshold <- median(boston$medv)
boston$price_category <- ifelse(boston$medv > threshold, "High", "Low")

# Convert price_category to factor
boston$price_category <- as.factor(boston$price_category)

# Step 3: Exploratory Data Analysis (EDA)

# 3.1: Check the structure and summary of the dataset
str(boston)
summary(boston)

# 3.2: Check for missing values
sum(is.na(boston))  # No missing values in this dataset

# 3.3: Check the distribution of the target variable
table(boston$price_category)

# Step 4: Split the dataset into training (80%) and testing (20%) sets
set.seed(42)
trainIndex <- createDataPartition(boston$price_category, p = 0.8, list = FALSE)
trainData <- boston[trainIndex, ]
testData <- boston[-trainIndex, ]

# Step 5: Train Classification Models

# 5.1: Logistic Regression Model
logit_model <- glm(price_category ~ ., data = trainData, family = "binomial")
logit_pred <- predict(logit_model, newdata = testData, type = "response")
logit_pred_class <- ifelse(logit_pred > 0.5, "High", "Low")
logit_pred_class <- factor(logit_pred_class, levels = levels(testData$price_category))

# 5.2: Random Forest Model
rf_model <- randomForest(price_category ~ ., data = trainData)
rf_pred <- predict(rf_model, newdata = testData)

# 5.3: Support Vector Machine (SVM) Model
svm_model <- svm(price_category ~ ., data = trainData)
svm_pred <- predict(svm_model, newdata = testData)

# Step 6: Model Evaluation

# 6.1: Confusion Matrix and Accuracy for Logistic Regression
logit_cm <- confusionMatrix(logit_pred_class, testData$price_category)
cat("Logistic Regression Accuracy: ", logit_cm$overall['Accuracy'], "\n")

# 6.2: Confusion Matrix and Accuracy for Random Forest
rf_cm <- confusionMatrix(rf_pred, testData$price_category)
cat("Random Forest Accuracy: ", rf_cm$overall['Accuracy'], "\n")

# 6.3: Confusion Matrix and Accuracy for SVM
svm_cm <- confusionMatrix(svm_pred, testData$price_category)
cat("SVM Accuracy: ", svm_cm$overall['Accuracy'], "\n")

# Step 7: Cross-Validation

# 7.1: Cross-validation for Random Forest
rf_cv_model <- train(price_category ~ ., data = trainData, method = "rf", 
                     trControl = trainControl(method = "cv", number = 10))
cat("Random Forest Cross-Validation Accuracy: ", rf_cv_model$results$Accuracy, "\n")

# 7.2: Cross-validation for SVM
svm_cv_model <- train(price_category ~ ., data = trainData, method = "svmRadial", 
                      trControl = trainControl(method = "cv", number = 10))
cat("SVM Cross-Validation Accuracy: ", svm_cv_model$results$Accuracy, "\n")

# Step 8: ROC Curve for Model Comparison
logit_roc <- roc(testData$price_category, as.numeric(logit_pred_class))
rf_roc <- roc(testData$price_category, as.numeric(rf_pred))
svm_roc <- roc(testData$price_category, as.numeric(svm_pred))

# Plot ROC curves
plot(logit_roc, col = "blue", main = "ROC Curves: Model Comparison")
lines(rf_roc, col = "red")
lines(svm_roc, col = "green")
legend("bottomright", legend = c("Logistic Regression", "Random Forest", "SVM"),
       col = c("blue", "red", "green"), lwd = 2)

# Step 9: Model Comparison Table
model_comparison <- data.frame(
  Model = c("Logistic Regression", "Random Forest", "Support Vector Machine"),
  Accuracy = c(logit_cm$overall['Accuracy'], rf_cm$overall['Accuracy'], svm_cm$overall['Accuracy'])
)

print(model_comparison)
